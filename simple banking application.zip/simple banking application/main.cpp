#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <fstream>

using namespace std;

//class Account Details
class AccDetails
{
private:
public:
     string Date;
     string AccNo;
     float balance;
};

//class Transaction details
class TranDetails
{
private:
public:
    string TransDaTe;
    string TypeofTrans;
    string CustomerAccNo;
    float Amount;

};

//Function to check balance
float CheckTheBal(float TotalBal, float *b)
{
	float a =0 ;

	if ((0<=TotalBal)&&(TotalBal<=1000))
    {
	    *b=10;
	     a = (TotalBal-*b);
	     return a;
	}

	if (TotalBal<0)
	{
	    *b=50;
		a = TotalBal-*b;
		return a;
	}

	if(TotalBal>1000)
	{
        return TotalBal;
    }
}

// function to calculate interest
float InTest(float balance, float *a)
{
    float CalInterest=0;
    cout << fixed<<setprecision(2);

    if (balance>0)
    {
        *a =(balance*0.02) / 100;

        float value = balance + (*a);
        return value;
    }

    return balance;
}

//function to print
void PrintText(string AccNo,string Date, int Type,float transAmount,float Bal)
{
    ofstream outfile2(AccNo+".txt", ios_base::app);
    outfile2 << Date<< "-----" <<Type << "-----" << fixed << setprecision(2) <<
    transAmount << "-----" << fixed << setprecision(2) <<Bal << endl;

}


int main()
{
    vector<AccDetails> Vec1;

    ifstream infile1("balance.txt");
    ifstream infile2("transaction.txt");

    string line;
    string text;

    AccDetails A;
    TranDetails B;
    int i;
    cout << fixed << setprecision(2);
    //open the text file 1
    if (infile1.is_open()) {
        while (infile1 >> line) { //getting inputs line by line
            stringstream ssA(line);
            i = 0;

            while (getline(ssA, text, ',')) { //getting word by word
                if (i == 0) {
                    A.Date = text;
                }
                if (i == 1) {
                    A.AccNo = text;
                }
                if (i == 2) {
                    A.balance = atoi(text.c_str());
                }
                i++;
            }
            Vec1.push_back(A);
        }


        for (int j = 0; j < Vec1.size(); j++) {

            ofstream file(Vec1[j].AccNo + ".txt");

            file << Vec1[j].Date << "," << "0" << "," << Vec1[j].balance << endl;
        }

        infile1.close();//closing the opened file
    }

    string BankAccNum = "111111";
    ofstream outfile2(BankAccNum + ".txt"); //creating new bank txt file
    float BankStVal = 2000000;
    outfile2 << Vec1[0].Date << "," << "0" << "," << fixed << setprecision(2) << BankStVal << "," << endl;

    string Transac;
    string CheckDate = Vec1[0].Date;
    int k;

    if (infile2.is_open()) { //opening file 2
        while (infile2 >> Transac) {
            stringstream ssa(Transac); //getting line by line
            k = 0;
            while (getline(ssa, Transac, ',')) {
                if (k == 0) {
                    B.TransDaTe = Transac;
                }
                if (k == 1) {
                    B.CustomerAccNo = Transac;
                }
                if (k == 2) {
                    B.TypeofTrans = Transac;
                }
                if (k == 3)
                {
                    B.Amount = atoi(Transac.c_str());
                }
                k++;
            }

            string Type = B.TypeofTrans;
            int n = atoi(Type.c_str()); //converting string in to int

            if (CheckDate != B.TransDaTe)
            {
                for (int a = 0; a < Vec1.size(); a++)
                {
                    float C = 0;
                    Vec1[0].balance = CheckTheBal(Vec1[a].balance, &C);
                    if (C > 0) {
                        PrintText(Vec1[a].AccNo, CheckDate, 4, C, Vec1[a].balance);

                        if (C == 10)
                        {
                            BankStVal += C;
                            ofstream outfile2("111111.txt", ios_base::app);
                            outfile2 << CheckDate << "-----" << 4 << "-----" << C << "," << fixed << setprecision(2)
                                     << BankStVal << endl;
                        }
                    }


                    float D = 0;
                    Vec1[a].balance = InTest(Vec1[a].balance, &D);
                    if (D > 0)
                    {
                        BankStVal -= D;
                        PrintText(Vec1[i].AccNo, B.TransDaTe, 3, D, Vec1[i].balance);
                        ofstream outfile2("111111.txt", ios_base::app);

                        outfile2 << B.TransDaTe << "-----" << 3 << "-----" << D << "," << fixed << setprecision(2)
                                 << BankStVal
                                 << endl;
                    }
                }
                CheckDate = B.TransDaTe;
            }


            for (int x = 0; x < Vec1.size(); x++)
            {
                if (B.CustomerAccNo == Vec1[x].AccNo)
                {
                    int x1 = 0;
                    if (x1 == 1)
                    {
                        float newbal1 = B.Amount + Vec1[x].balance;
                        Vec1[x].balance = newbal1;
                        BankStVal -= B.Amount;

                    }
                    if (x1 == 2)
                    {
                        float newbal2 = Vec1[x].balance - B.Amount;
                        Vec1[x].balance = newbal2;
                        BankStVal += B.Amount;
                        break;
                    } else {
                        break;
                    }

                }

                ofstream outfile3(B.CustomerAccNo + ".txt", ios_base::app);
                outfile3 << B.TransDaTe << "-----" << B.TypeofTrans << "-----" << fixed << setprecision(2) <<
                         B.Amount << "-----" << fixed << setprecision(2) << Vec1[x].balance << endl;
                ofstream file2("111111.txt", ios_base::app);

                outfile2 << B.TransDaTe << "-----" << B.TypeofTrans << "-----" << fixed << setprecision(2) <<
                         B.Amount << "-----" << fixed << setprecision(2) << BankStVal << endl;
            }
        }
    }
    infile2.close();//close file

    for (int i1= 0; i1 < Vec1.size(); i1++)
    {
        float D = 0;
        Vec1[i1].balance = CheckTheBal(Vec1[i1].balance, &D);
        if (D != 0)
        {
            PrintText(Vec1[i1].AccNo, CheckDate, 4, D, Vec1[i1].balance);
             if (D== 10)
             {
              BankStVal+= D;
              PrintText(BankAccNum, CheckDate, 4, D, BankStVal);
             }
        }
    }

    float CurrBal=0;
    for (int i2 = 0; i2 < Vec1.size(); i2++)
    {
    CurrBal += Vec1[i2].balance;
    }

cout <<"\t\t\t\t   Choose one of below::" << endl<<endl<<endl<<endl;
cout << "\t 1) View bank Balance " << endl;
cout << "\t 2) View Current balance of all customer accounts  " << endl;
cout << "\t 3) Exit the program  " << endl;

int Select=0;
    while ( Select!=3)
    {
        cout << "Enter the number : ";
        cin >> Select;
                system("CLS");

    cout << " Customer account"<<endl;
    cout << "1) Current Bank Balance " << endl;
    cout <<" 2) Current Balance of all customer accounts" << endl;
    cout << " 3) exit the program  " << endl;
    cout << "\n\n\n" << endl;

   if(Select==1)
   {
       cout<< " Current Bank Balance = "<<BankStVal<<endl;
   }
   if(Select==2)
   {
       cout<< " Current Balance of all the accounts = "<< CurrBal<<endl;
   }
    }

return 0;
}